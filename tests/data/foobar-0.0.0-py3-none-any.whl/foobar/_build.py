# autogenerate build file
branch = 'master'
build = 0
current = '0.0.0'
ref = 'refs/heads/master'
runid = 0
sha = '795ee3855a857e4cddf1e3bdbd4af864d26f6666'
version = '0.0.0'
workflow = 'master'
